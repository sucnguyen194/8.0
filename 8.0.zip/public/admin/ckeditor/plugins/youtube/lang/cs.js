﻿CKEDITOR.plugins.setLang('youtube', 'cs', {
	button : 'Vložit video YouTube',
	title : 'Vložit video YouTube',
	txtEmbed : 'Zde vložte kód pro vložení',
	txtUrl : 'Vložte adresu URL videa YouTube',
	txtWidth : 'Šířka',
	txtHeight : 'Výška',
	chkRelated : 'Po dohrání videa zobrazit navrhovaná videa',
	txtStartAt : 'Začít přehrávat v čase (ss nebo mm:ss nebo hh:mm:ss)',
	chkPrivacy : 'Povolit režim s rozšířeným soukromím',
	chkOlderCode : 'Použít starý kód pro vložení',
	chkAutoplay : 'Automatické spuštění přehrávání',
	noCode : 'Musíte vložit kód pro vložení nebo adresu URL',
	invalidEmbed : 'Vložený kód pro vložení zřejmě není platný',
	invalidUrl : 'Zadaná adresa URL zřejmě není platná',
	or : 'nebo',
	noWidth : 'Musíte zadat šířku',
	invalidWidth : 'Zadejte platnou šířku',
	noHeight : 'Musíte zadat výšku',
	invalidHeight : 'Zadejte platnou výšku',
	invalidTime : 'Zadejte platný počáteční čas',
	txtResponsive : 'Responzivní design (ignorovat výšku a šířku, uzpůsobit šířce)'
});
