CKEDITOR.plugins.setLang('youtube', 'et', {
	button : 'Lisa YouTube video',
	title : 'YouTube video lisamine',
	txtEmbed : 'Kleepige manustatud kood siia',
	txtUrl : 'Kleepige YouTube video veebiaadress',
	txtWidth : 'Laius',
	txtHeight : 'Kõrgus',
	chkRelated : 'Näita soovitatud videosi antud video lõppus',
	txtStartAt : 'Alguskoht: (ss või mm:ss või hh:mm:ss)',
	chkPrivacy : 'Aktiveerige privaatsust täiendav režiim',
	chkOlderCode : 'Kasutage vana manuskoodi',
	chkAutoplay: 'Automaatesitlus',
	noCode : 'Te peate sisestama video manuskoodi või veebiaadressi',
	invalidEmbed : 'Manuskood mille sisestasite ei paista olevat korrektne',
	invalidUrl : 'Veebiaadress mille sisestasite ei paista olevat korrektne',
	or : 'või',
	noWidth : 'Te peate sisestama video laiuse',
	invalidWidth : 'Sisestage korrektne laius',
	noHeight : 'Te peate sisestama video kõrguse',
	invalidHeight : 'Sisestage korrektne kõrgus',
	invalidTime : 'Sisestage korrektne algusaeg',
	txtResponsive : 'Aktiveerige ekraani laiusega ühilduv režiim'
});
